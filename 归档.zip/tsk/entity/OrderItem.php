<?php
class OrderItem{
	public $itemId;
	public $itemName;
	public $price;
	public $totalFee;
	public $count;
	public function __construct() {
    }
}
?>